# 140-Day Rosary Journey
Responsive, interactive devotional web app for GitHub Pages.

## Run
Open `index.html` locally, or upload the whole folder to a GitHub repository and enable GitHub Pages.

## Features
- 140-day progression
- Joyful/Sorrowful/Glorious/Luminous rotation
- Interactive Rosary bead tracker
- Daily opening/decade/closing prayer structure
- 10 Hail Mary intentions per decade
- Scripture cards
- Reflection spaces saved in browser localStorage
- Prayer journal
- Responsive iPad/mobile/desktop layout
- Print view

The current Scripture excerpts are short quotations. Replace/add quotations only with translations and sources whose licensing permits your intended use, and retain attribution.
